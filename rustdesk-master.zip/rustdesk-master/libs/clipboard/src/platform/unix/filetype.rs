use super::{
    FILE_NAME_FIELD_SIZE, FLAGS_FD_ATTRIBUTES, FLAGS_FD_LAST_WRITE, FLAGS_FD_UNIX_MODE,
    LDAP_EPOCH_DELTA,
};
use crate::CliprdrError;
use hbb_common::{
    bytes::{Buf, Bytes},
    log,
};
use serde_derive::{Deserialize, Serialize};
use std::{
    path::PathBuf,
    time::{Duration, SystemTime},
};
use utf16string::WStr;

#[cfg(target_os = "linux")]
pub type Inode = u64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FileType {
    File,
    Directory,
    // todo: support symlink
    Symlink,
}

/// read only permission
pub const PERM_READ: u16 = 0o444;
/// read and write permission
pub const PERM_RW: u16 = 0o644;
/// only self can read and readonly
pub const PERM_SELF_RO: u16 = 0o400;
/// rwx
pub const PERM_RWX: u16 = 0o755;
#[allow(dead_code)]
/// max length of file name
pub const MAX_NAME_LEN: usize = 255;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct FileDescription {
    pub conn_id: i32,
    pub name: PathBuf,
    pub kind: FileType,
    pub atime: SystemTime,
    pub last_modified: SystemTime,
    pub last_metadata_changed: SystemTime,
    pub creation_time: SystemTime,
    pub size: u64,
    pub perm: u16,
    /// `file_list_id()` of the list this file came from, sent back in file contents requests
    #[serde(default)]
    pub clip_data_id: i32,
}

/// Identifies a file list by its descriptor PDU, which both peers hold, so file contents
/// requests can name the list they read from. FNV-1a, same as `wf_cliprdr_file_list_id()`.
pub fn file_list_id(file_descriptor_pdu: &[u8]) -> i32 {
    file_descriptor_pdu
        .iter()
        .fold(0x811c_9dc5_u32, |id, byte| {
            (id ^ *byte as u32).wrapping_mul(0x0100_0193)
        }) as i32
}

pub(super) fn validate_file_name(name: &str) -> Result<(), CliprdrError> {
    if matches!(name.as_bytes(), [letter, b':', b'/', ..] if letter.is_ascii_alphabetic())
        || name
            .split('/')
            .any(|component| component.is_empty() || component == ".")
    {
        return Err(CliprdrError::InvalidRequest {
            description: "clipboard file name is not a normalized relative path".to_string(),
        });
    }
    base::fs::validate_file_name_no_traversal(name).map_err(|error| CliprdrError::InvalidRequest {
        description: error.to_string(),
    })
}

impl FileDescription {
    fn parse_file_descriptor(
        bytes: &mut Bytes,
        conn_id: i32,
        clip_data_id: i32,
    ) -> Result<FileDescription, CliprdrError> {
        let flags = bytes.get_u32_le();
        // skip reserved 32 bytes
        bytes.advance(32);
        let attributes = bytes.get_u32_le();

        // in original specification, this is 16 bytes reserved
        // we use the last 4 bytes to store the file mode
        // skip reserved 12 bytes
        bytes.advance(12);
        let perm = bytes.get_u32_le() as u16;

        // last write time from 1601-01-01 00:00:00, in 100ns
        let last_write_time = bytes.get_u64_le();
        // file size
        let file_size_high = bytes.get_u32_le();
        let file_size_low = bytes.get_u32_le();
        // NUL-terminated UTF-16 file name in a fixed-size field.
        // read with another pointer, and advance the main pointer
        let block = bytes.clone();
        bytes.advance(FILE_NAME_FIELD_SIZE);

        let block = &block[..FILE_NAME_FIELD_SIZE];
        let utf16_unit_size = std::mem::size_of::<u16>();
        let name_end = block
            .chunks_exact(utf16_unit_size)
            .position(|unit| unit == [0_u8, 0_u8])
            .ok_or_else(|| CliprdrError::InvalidRequest {
                description: "clipboard file name is not null-terminated".to_string(),
            })?
            * utf16_unit_size;
        let wstr = WStr::from_utf16le(&block[..name_end]).map_err(|e| {
            log::error!("cannot convert file descriptor path: {:?}", e);
            CliprdrError::ConversionFailure
        })?;

        let from_unix = flags & FLAGS_FD_UNIX_MODE != 0;

        let valid_attributes = flags & FLAGS_FD_ATTRIBUTES != 0;
        if !valid_attributes {
            return Err(CliprdrError::InvalidRequest {
                description: "file description must have valid attributes".to_string(),
            });
        }

        // todo: check normal, hidden, system, readonly, archive...
        let directory = attributes & 0x10 != 0;
        let normal = attributes == 0x80;
        let hidden = attributes & 0x02 != 0;
        let readonly = attributes & 0x01 != 0;

        let perm = if from_unix {
            // as is
            perm
            // cannot set as is...
        } else if normal {
            PERM_RWX
        } else if directory {
            // Windows ignores read-only and hidden on a directory; without `x` it cannot be entered.
            PERM_RWX
        } else if readonly {
            PERM_READ
        } else if hidden {
            PERM_SELF_RO
        } else {
            PERM_RW
        };

        let kind = if directory {
            FileType::Directory
        } else {
            FileType::File
        };

        // to-do: use `let valid_size = flags & FLAGS_FD_SIZE != 0;`
        // We use `true` to for compatibility with Windows.
        // let valid_size = flags & FLAGS_FD_SIZE != 0;
        let valid_size = true;
        let size = if valid_size {
            ((file_size_high as u64) << 32) + file_size_low as u64
        } else {
            0
        };

        let valid_write_time = flags & FLAGS_FD_LAST_WRITE != 0;
        let last_modified = if valid_write_time && last_write_time >= LDAP_EPOCH_DELTA {
            let last_write_time = last_write_time - LDAP_EPOCH_DELTA;
            let last_write_time = Duration::new(
                last_write_time / 10_000_000,
                (last_write_time % 10_000_000) as u32 * 100,
            );
            SystemTime::UNIX_EPOCH + last_write_time
        } else {
            SystemTime::UNIX_EPOCH
        };

        let name = wstr.to_utf8().replace('\\', "/");
        validate_file_name(&name)?;
        let name = PathBuf::from(name);

        let desc = FileDescription {
            conn_id,
            name,
            kind,
            atime: last_modified,
            last_modified,
            last_metadata_changed: last_modified,
            creation_time: last_modified,
            size,
            perm,
            clip_data_id,
        };

        Ok(desc)
    }

    /// parse file descriptions from a format data response PDU
    /// which containing a CSPTR_FILEDESCRIPTORW indicated format data
    pub fn parse_file_descriptors(
        file_descriptor_pdu: Vec<u8>,
        conn_id: i32,
    ) -> Result<Vec<Self>, CliprdrError> {
        let clip_data_id = file_list_id(&file_descriptor_pdu);
        let mut data = Bytes::from(file_descriptor_pdu);
        if data.remaining() < 4 {
            return Err(CliprdrError::InvalidRequest {
                description: "file descriptor request with infficient length".to_string(),
            });
        }

        let count = data.get_u32_le() as usize;
        if data.remaining() == 0 && count == 0 {
            return Ok(Vec::new());
        }

        if data.remaining() != 592 * count {
            return Err(CliprdrError::InvalidRequest {
                description: "file descriptor request with invalid length".to_string(),
            });
        }

        let mut files = Vec::with_capacity(count);
        for _ in 0..count {
            let desc = Self::parse_file_descriptor(&mut data, conn_id, clip_data_id)?;
            files.push(desc);
        }

        Ok(files)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::mem::size_of;

    const PDU_HEADER_SIZE: usize = size_of::<u32>();
    const DESCRIPTOR_SIZE: usize = 592;
    const ATTRIBUTES_OFFSET: usize = PDU_HEADER_SIZE + 36;
    const LAST_WRITE_TIME_OFFSET: usize = PDU_HEADER_SIZE + 56;
    const NAME_OFFSET: usize = PDU_HEADER_SIZE + 72;
    const FILE_ATTRIBUTE_NORMAL: u32 = 0x80;

    fn descriptor_pdu(name: &str) -> Vec<u8> {
        let mut pdu = vec![0_u8; PDU_HEADER_SIZE + DESCRIPTOR_SIZE];
        pdu[..PDU_HEADER_SIZE].copy_from_slice(&1_u32.to_le_bytes());
        pdu[PDU_HEADER_SIZE..PDU_HEADER_SIZE + size_of::<u32>()]
            .copy_from_slice(&FLAGS_FD_ATTRIBUTES.to_le_bytes());
        pdu[ATTRIBUTES_OFFSET..ATTRIBUTES_OFFSET + size_of::<u32>()]
            .copy_from_slice(&FILE_ATTRIBUTE_NORMAL.to_le_bytes());
        for (index, unit) in name.encode_utf16().enumerate() {
            let offset = NAME_OFFSET + index * size_of::<u16>();
            pdu[offset..offset + size_of::<u16>()].copy_from_slice(&unit.to_le_bytes());
        }
        pdu
    }

    fn parse_name(name: &str) -> Result<Vec<FileDescription>, CliprdrError> {
        FileDescription::parse_file_descriptors(descriptor_pdu(name), 0)
    }

    #[test]
    fn rejects_unsafe_file_names() {
        for name in [
            "../payload",
            "/tmp/payload",
            "C:\\payload",
            "folder//payload",
            "folder/./payload",
            "folder/",
            "",
            ".",
        ] {
            assert!(matches!(
                parse_name(name),
                Err(CliprdrError::InvalidRequest { .. })
            ));
        }
    }

    #[test]
    fn accepts_nested_relative_file_name() {
        let files = parse_name("folder\\nested\\file.txt").unwrap();
        assert_eq!(files[0].name, PathBuf::from("folder/nested/file.txt"));
    }

    #[test]
    fn file_list_id_is_fnv1a() {
        // Reference vectors; the Windows side computes the same id in C.
        assert_eq!(file_list_id(b"") as u32, 0x811c_9dc5);
        assert_eq!(file_list_id(b"a") as u32, 0xe40c_292c);
        assert_eq!(file_list_id(b"foobar") as u32, 0xbf9c_f968);
    }

    #[test]
    fn parsed_files_carry_their_list_id() {
        let pdu = descriptor_pdu("file.txt");
        let id = file_list_id(&pdu);
        let files = FileDescription::parse_file_descriptors(pdu, 0).unwrap();
        assert_eq!(files[0].clip_data_id, id);
    }

    fn parse_perm(attributes: u32) -> u16 {
        let mut pdu = descriptor_pdu("folder");
        pdu[ATTRIBUTES_OFFSET..ATTRIBUTES_OFFSET + size_of::<u32>()]
            .copy_from_slice(&attributes.to_le_bytes());
        FileDescription::parse_file_descriptors(pdu, 0).unwrap()[0].perm
    }

    #[test]
    fn windows_directories_stay_searchable() {
        const FILE_ATTRIBUTE_READONLY: u32 = 0x01;
        const FILE_ATTRIBUTE_HIDDEN: u32 = 0x02;
        const FILE_ATTRIBUTE_DIRECTORY: u32 = 0x10;
        for attributes in [
            FILE_ATTRIBUTE_DIRECTORY,
            FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_READONLY,
            FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_HIDDEN,
        ] {
            assert_eq!(
                parse_perm(attributes),
                PERM_RWX,
                "attributes {attributes:#x}"
            );
        }
    }

    fn parse_last_write_time(filetime: u64) -> SystemTime {
        let mut pdu = descriptor_pdu("file.txt");
        pdu[PDU_HEADER_SIZE..PDU_HEADER_SIZE + size_of::<u32>()]
            .copy_from_slice(&(FLAGS_FD_ATTRIBUTES | FLAGS_FD_LAST_WRITE).to_le_bytes());
        pdu[LAST_WRITE_TIME_OFFSET..LAST_WRITE_TIME_OFFSET + size_of::<u64>()]
            .copy_from_slice(&filetime.to_le_bytes());
        FileDescription::parse_file_descriptors(pdu, 0).unwrap()[0].last_modified
    }

    #[test]
    fn decodes_last_write_time_from_windows_filetime() {
        // 2023-11-14 22:13:20 UTC
        assert_eq!(
            parse_last_write_time(133_444_736_000_000_000),
            SystemTime::UNIX_EPOCH + Duration::from_secs(1_700_000_000)
        );
        // 3000-01-01 00:00:00 UTC
        assert_eq!(
            parse_last_write_time(441_481_536_000_000_000),
            SystemTime::UNIX_EPOCH + Duration::from_secs(32_503_680_000)
        );
        // 1969-12-31 23:59:59 UTC falls back to the Unix epoch.
        assert_eq!(
            parse_last_write_time(116_444_736_000_000_000 - 10_000_000),
            SystemTime::UNIX_EPOCH
        );
    }
}
